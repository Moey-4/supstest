ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Hackable Console"
ENT.Author = "Moe"
ENT.Category = "Hack Test"
ENT.Spawnable = true
