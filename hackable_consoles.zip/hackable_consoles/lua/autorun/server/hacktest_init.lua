AddCSLuaFile()
AddCSLuaFile("weapons/weapon_hacktool/cl_init.lua")
AddCSLuaFile("autorun/client/cl_hacking_minigame.lua")
